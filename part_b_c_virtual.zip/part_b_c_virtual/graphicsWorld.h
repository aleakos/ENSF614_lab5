
#ifndef GRAPHIX
#define GRAPHIX

#include "rectangle.h"
#include "curveCut.h"

class GraphicsWorld
{
public:
    void run();
};

#endif