
#include <iostream>
#include "graphicsWorld.h"

int main()
{
    GraphicsWorld running = GraphicsWorld();
    running.run();
}
